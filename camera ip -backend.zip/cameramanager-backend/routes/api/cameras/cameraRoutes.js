const express = require('express');
const Camera = require('../../../models/cameraModel');  
const router = express.Router();

router.post('/', async (req, res) => {
    const { ip, username, password, resolution, frameRate, compressionEnabled, motionDetectionEnabled } = req.body;

    try {
        // Check if a camera with the same IP or username already exists
        const existingCamera = await Camera.findOne({ $or: [{ ip }, { username }] });

        if (existingCamera) {
            return res.status(400).json({ message: 'Camera with this IP or Name already exists!' });
        }

        // Save the new camera data
        const newCamera = new Camera({ ip, username, password, resolution, frameRate, compressionEnabled, motionDetectionEnabled });
        await newCamera.save();

        res.status(200).json({
            message: 'Camera added successfully!',
            data: newCamera
        });

    } catch (error) {
        console.error('Error saving camera data:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});
router.get('/', async (req, res) => {
    try {
        const cameras = await Camera.find({});
        res.status(200).json(cameras);  // Send the list of cameras
    } catch (error) {
        console.error('Error fetching cameras:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});
module.exports = router;
