const mongoose = require('mongoose');

// Define the camera schema
const cameraSchema = new mongoose.Schema({
    ip: { type: String, unique: true, required: true },
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    resolution: { type: String, required: true },
    frameRate: { type: String, required: true },
    compressionEnabled: { type: Boolean, default: false },
    motionDetectionEnabled: { type: Boolean, default: false }
});

// Create the Camera model
const Camera = mongoose.model('Camera', cameraSchema);

module.exports = Camera;
