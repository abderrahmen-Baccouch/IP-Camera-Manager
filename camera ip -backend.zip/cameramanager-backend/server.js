const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const authRoutes = require('./routes/api/auth/authRoutes');  // Routes d'authentification
const cameraRoutes = require('./routes/api/cameras/cameraRoutes');  // Routes des caméras
const app = express();
const port = process.env.PORT || 3000;
const http = require('http');
const WebSocket = require('ws');

// Créer un serveur HTTP
const server = http.createServer(app);

// Créer un serveur WebSocket
const wss = new WebSocket.Server({ server });

// Gérer les connexions WebSocket
wss.on('connection', (ws) => {
    console.log('Nouvelle connexion WebSocket établie.');

    // Envoyer un message au client lorsqu'il est connecté
    ws.send(JSON.stringify({ message: 'Connecté au flux caméra' }));

    // Gérer les messages entrants du client
    ws.on('message', (message) => {
        console.log('Reçu:', message);
    });

    // Simuler l'envoi d'une URL de flux toutes les 10 secondes
    const streamUrl = 'http://192.168.100.228:8080/';  // Modifiez l'URL du flux vidéo ici
    setInterval(() => {
        ws.send(JSON.stringify({ type: 'stream', url: streamUrl }));
    }, 10000);  // Envoi toutes les 10 secondes
});

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Connexion MongoDB (si nécessaire)
mongoose.connect('mongodb://localhost:27017/cameraDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    console.log('MongoDB connecté avec succès');
})
.catch((err) => {
    console.error('Erreur de connexion à MongoDB:', err);
});

// Routes d'API
app.use('/api/auth', authRoutes);  // Routes d'authentification
app.use('/api/cameras', cameraRoutes);  // Routes pour gérer les caméras

// Démarrer le serveur HTTP
server.listen(port, () => {
    console.log(`Serveur démarré sur http://localhost:${port}`);
});
