// Données utilisateur en dur (en production, tu utiliserais une base de données)
const users = [
    {
      username: 'admin',
      password: 'admin',  // Le mot de passe en clair (NON recommandé en production)
    }
  ];
  
  // Fonction de connexion (login)
  const login = (req, res) => {
    const { username, password } = req.body;
  
    // Vérifier que l'utilisateur existe
    const user = users.find(u => u.username === username);
    if (!user) {
      return res.status(400).json({ message: 'Utilisateur non trouvé' });
    }
  
    // Vérifier si le mot de passe est correct
    if (password !== user.password) {
      return res.status(400).json({ message: 'Mot de passe incorrect' });
    }
  
    // Si tout est bon, répondre avec un message de succès
    res.json({ message: 'Connexion réussie', role: 'admin' });
  };
  
  module.exports = { login };
  