const express = require('express');
const WebSocket = require('ws');
const app = express();
const port = 3000;

const wss = new WebSocket.Server({ noServer: true });

wss.on('connection', (ws) => {
  console.log('New WebSocket connection');

  // Handle incoming messages (camera feed data, commands, etc.)
  ws.on('message', (message) => {
    console.log('Received: %s', message);
  });

  // Send a message to the client (e.g., camera stream start message)
  ws.send('Camera connected!');

  // Simulate video stream (just a string for now, replace with actual video stream data)
  setInterval(() => {
    ws.send('Video frame data');
  }, 1000);
});

// Handle the HTTP upgrade to WebSocket request
app.server = app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

app.server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});
